//package com.ayaagroup.demo.controller;
//
////import com.ayaagroup.demo.dao.PatientDao;
//import model.entity.prescription.ScanResult;
//import model.entity.prescription.TestResults;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class UploadController {
////
////    @Autowired
////    private PatientDao patientDao;
////
////    @PostMapping(path = "/prescription/LabSection/RequiredScans/save-scans")
////    public ScanResult saveScanResult(@RequestBody ScanResult scanImage){
////        return this.patientDao.saveScanResult(scanImage);
////    }
////
////    @PostMapping(path = "/prescription/LabSection/RequiredTests/save-testResult")
////    public TestResults saveTestResult(@RequestBody TestResults testResult) {
////        return this.patientDao.saveTestResults(testResult);
////    }
//}
