package com.healthcare.app.repository;

import com.healthcare.app.model.entity.user.patient.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PatientDiseaseRepo extends JpaRepository<Patient,Integer> {
  // Optional<PatientDiseaseEntity> findAllById(Integer id);
   // Optional<PatientDiseaseEntity> findPatientByPatientID(Integer id);

}
