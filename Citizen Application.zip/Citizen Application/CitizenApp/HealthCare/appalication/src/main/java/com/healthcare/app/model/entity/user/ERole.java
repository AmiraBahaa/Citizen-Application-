package com.healthcare.app.model.entity.user;

public enum ERole {
    ROLE_PATIENT,
    ROLE_DIAGNOTIC_DOCTOR,
    ROLE_PHARMACIST,
    ROLE_LAB_TECHNICIAN,
    ROLE_ADMIN
}
