package com.healthcare.app.controller;

//import com.ayaagroup.demo.dao.PatientDao;

//import com.ayaagroup.demo.entity.prescription.*;
import com.healthcare.app.Service.BasicInfoService;
import com.healthcare.app.model.dto.BasicInfoDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class PatientController {
    @Autowired
    private BasicInfoService bsicInfoService;

//    @Autowired
//    private PatientDao patientDao;

    @GetMapping("/BasicInfoDto")
public BasicInfoDto getBasicInfo(@RequestParam Integer id){
        return bsicInfoService.getBasicInfo(id);
    }

//   @GetMapping("/BasicInformation")
//    public List<PatientDiseaseEntity> getPatients(@RequestParam Patient Id){
//        return this.patientDao.getPatients(Id);
//    }
//    @GetMapping("/BasicInformation")
//    public List<PatientDiseaseEntity> getPatients(@RequestParam Patient Id){
//        return this.patientDao.getPatients(Id);
//    }
//
//    @GetMapping("/currentMedicine")
//    public List<RequiredMedication> findAllMedicine(@RequestParam Integer Id){
//        return this.patientDao.findAllByPrescriptionEntities(Id);
//    }




}
