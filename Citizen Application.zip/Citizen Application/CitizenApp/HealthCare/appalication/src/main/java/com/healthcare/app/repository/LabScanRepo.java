package com.healthcare.app.repository;

import com.healthcare.app.model.entity.prescription.LabScans;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LabScanRepo extends JpaRepository<LabScans,Integer> {
    Optional<LabScans> findAllByPreId(Integer Id);
}
