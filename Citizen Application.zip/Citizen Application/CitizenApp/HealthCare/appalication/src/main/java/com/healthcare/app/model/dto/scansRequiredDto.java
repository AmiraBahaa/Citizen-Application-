package com.healthcare.app.model.dto;

import com.healthcare.app.model.entity.prescription.LabScans;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class scansRequiredDto {


    private String scanName;

    private String notes;
    private String scanResult;


    public static scansRequiredDto toDto(LabScans scan){
        return scansRequiredDto.builder()

                .scanName(scan.getScanName())
                .notes(scan.getNotes())
                .scanResult(scan.getScanResult())
                .build();
    }

}
