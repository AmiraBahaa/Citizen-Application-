//package com.ayaagroup.demo.repository;
//
//import model.entity.prescription.LabTests;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository
//public interface LabTestRepo extends JpaRepository<LabTests,Integer> {
//
//    //return all prescriptions
//    @Query("select t from LabTests t")
//    List<LabTests> findAll();
//
//    List<LabTests> findLabTestsByPreId(Integer Id);
//}
