package com.healthcare.app.model.entity.user.patient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "patient Diseases")

public class PatientDiseaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "patientDisease_id")
    private Integer pdId;

    @JsonBackReference
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", insertable = false, updatable = false)
    private Patient patientId;

    @JsonBackReference
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "disease_id", insertable = false, updatable = false)
    private DiseaseEntity diseaseEntity;

    @Column(name = "blood_pressure")
    private String bloodPressure;

    @Column(name = "blood_type")
    private String bloodType;

    @Column(name = "diabietes")
    private String Diabietes;

    @Column(name = "heart_disease")
    private String heartDisease;

    @Column(name = "alcohol")
    private String Alcohol;

    @Column(name = "physical_or_mental")
    private String treatment;

    @Column(name = "tumors")
    private String tumors;

}
