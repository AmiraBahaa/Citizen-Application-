package com.healthcare.app.model.dto;

import lombok.Data;

@Data
public class ContactUsDto {

        private Integer TicketId;

        private String name;

        private String email;

        private String message;

        private String  phone;

    }


