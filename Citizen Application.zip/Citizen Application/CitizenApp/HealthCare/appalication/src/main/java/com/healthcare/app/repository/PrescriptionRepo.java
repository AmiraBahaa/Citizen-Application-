//package com.ayaagroup.demo.repository;
//
//import model.entity.prescription.PrescriptionEntity;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface PrescriptionRepo extends JpaRepository<PrescriptionEntity,Integer> {
//
//   // PrescriptionEntity findPrescriptionEntitiesByPrescriptionId (Integer Id);
//}
