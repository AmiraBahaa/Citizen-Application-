package com.healthcare.app.Service;

import com.healthcare.app.model.dto.BasicInfoDto;
import com.healthcare.app.model.dto.scansRequiredDto;
import com.healthcare.app.model.entity.prescription.LabScans;
import com.healthcare.app.model.entity.user.patient.PatientDiseaseEntity;
import com.healthcare.app.repository.LabScanRepo;
import com.healthcare.app.repository.PatientDiseaseRepo;
import com.healthcare.app.repository.PatientRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class BasicInfoService {
        @Autowired
    private PatientRepo patientRepo;

    @Autowired
    private PatientDiseaseRepo patientDiseaseRepo;

        @Autowired
        private LabScanRepo labScanRepo;

    //    public List<PatientDiseaseEntity> getPatients(Patient Id){
//        return this.test.findPatientDiseaseEntityByPatientId(Id);
//    }
public BasicInfoDto getBasicInfo(Integer id){
    Optional<PatientDiseaseEntity> patient = this.patientDiseaseRepo.findById(id);
    if(patient.isPresent())
        return BasicInfoDto.toDto(patient.get());
    else
        return null;
}


    public scansRequiredDto getScan(Integer id){
        Optional<LabScans> scan = this.labScanRepo.findById(id);
        if(scan.isPresent())
            return scansRequiredDto.toDto(scan.get());
        else
            return null;
    }

    //    public List<LabScans> findLabScansByPrescriptionId(Integer Id){
//        return this.lab.findAllByPreId(Id);
//    }

}