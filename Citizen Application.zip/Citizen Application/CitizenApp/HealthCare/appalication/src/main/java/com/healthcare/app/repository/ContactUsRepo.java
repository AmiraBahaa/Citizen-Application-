package com.healthcare.app.repository;


import com.healthcare.app.model.entity.ContactUs.ContactUs;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ContactUsRepo extends JpaRepository<ContactUs, Integer> {
//    List<RequiredMedication> findRequiredMedicationByPrescriptionId(Integer prescriptionId);


   //  List<ContactUs> findContactUsByTicketId(Integer id);

}
