//package com.ayaagroup.demo.dao;
//
//import model.entity.ContactUs.ContactUs;
//import model.entity.ContactUs.LostCard;
//import com.ayaagroup.demo.entity.prescription.*;
//import model.entity.prescription.*;
//import model.entity.user.patient.Patient;
//import model.entity.user.patient.PatientDiseaseEntity;
//import com.ayaagroup.demo.repository.*;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class PatientDao {
//    @Autowired
//    private PatientDiseaseRepo repo;
//
//    @Autowired
//    private PatientRepo test;
//
//    @Autowired
//    private MedicineRepo medRepo;
//
//    @Autowired
//    private LabScanRepo lab;
//
//    @Autowired
//    private TestRepo testrepo;
//
//    @Autowired
//    private PrescriptionRepo preRepo;
//
//    @Autowired
//    private ContactUsRepo contactUsRepo;
//
//    @Autowired
//    private TestResultRepo testResultRepo;
//
//    @Autowired
//    private ScanResultRepo scanResultRepo;
//
//    @Autowired
//    private LostCardRepo lostCardRepo;
//
//    @Autowired
//    private LabTestRepo labTestRepo;
//
//    public ContactUs addContact(ContactUs contact) {
//        return this.contactUsRepo.save(contact);
//    }
//
//    public LostCard addrequest(LostCard card) {
//        return this.lostCardRepo.save(card);
//    }
//
//
//    public List<Patient> getDiseases(Integer ID){
//        return this.repo.findPatientByPatientID(ID);
//    }
//
//    public List<PatientDiseaseEntity> getPatients(Patient Id){
//        return this.test.findPatientDiseaseEntityByPatientId(Id);
//    }
//
//    public List<RequiredMedication> findAllByPrescriptionEntities(Integer Id){
//        return this.medRepo.findAllByPrescriptionId(Id);
//    }
//
//    public List<LabScans> findLabScansByPrescriptionId(Integer Id){
//        return this.lab.findAllByPreId(Id);
//    }
//
//    public List<LabTests> findAllByPreId(Integer Id){
//        return this.testrepo.findAllByPreId(Id);
//    }
//
//    public List<LabTests> findLabTestByPrescriptionId(Integer id){
//        return this.labTestRepo.findLabTestsByPreId(id);
//    }
//
//    public TestResults saveTestResults(TestResults testResult){
//        return this.testResultRepo.save(testResult);
//    }
//
//    public ScanResult saveScanResult(ScanResult scanImage){
//        return this.scanResultRepo.save(scanImage);
//    }
//}
