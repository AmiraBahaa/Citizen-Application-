//package com.ayaagroup.demo.repository;
//
//import model.entity.prescription.RequiredMedication;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository
//public interface MedicineRepo extends JpaRepository<RequiredMedication, Integer> {
//    //return all prescriptions
//    @Query("select t from RequiredMedication t")
//    List<RequiredMedication> findAll();
//
//    //to get the required medicine for current medicine page by prescription Id
//    List<RequiredMedication> findAllByPrescriptionId(Integer Id);
//}
