package com.healthcare.app.model.entity.user.patient;

import com.healthcare.app.model.entity.user.patient.insurance.Insurance;
import com.healthcare.app.model.entity.user.User;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "patients")
public class Patient {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "patient_id")
    private Integer patientID;

    @Column(name = "overview_state")
    private String overviewState;

    @JsonManagedReference
    @OneToMany(mappedBy = "patientEntity")
    private List<Insurance> insurances;

    @JsonManagedReference
    @OneToMany(mappedBy = "patientId")
    private List<PatientDiseaseEntity> patientDiseaseEntities;

    @JsonBackReference
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private User user;

}
