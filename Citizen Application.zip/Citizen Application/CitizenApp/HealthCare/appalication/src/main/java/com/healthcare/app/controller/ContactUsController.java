//package com.ayaagroup.demo.controller;
//
////import com.ayaagroup.demo.dao.PatientDao;
//import model.entity.ContactUs.ContactUs;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("contactUs")
//public class ContactUsController {
//
//   // @Autowired
//    //private PatientDao patientDao;
////
////    @PostMapping("/ContactUs")
////    public ContactUs addContact(@RequestBody ContactUs contact) {
////        return this.patientDao.addContact(contact);
////    }
//
//
//}
