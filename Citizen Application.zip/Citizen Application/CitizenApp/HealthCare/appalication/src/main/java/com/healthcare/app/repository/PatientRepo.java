package com.healthcare.app.repository;

import com.healthcare.app.model.entity.user.patient.PatientDiseaseEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PatientRepo extends JpaRepository<PatientDiseaseEntity,Integer> {

    //find all basic information for patient by patientId
  //Optional<PatientDiseaseEntity> findPatientDiseaseEntityByPatientId(Patient Id);
}
