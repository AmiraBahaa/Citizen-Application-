//package com.ayaagroup.demo.controller;
//
////import com.ayaagroup.demo.dao.PatientDao;
//import model.entity.ContactUs.LostCard;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class LostController {
//
////    @Autowired
////    private PatientDao patientDao;
////
////    @PostMapping("/LostCard")
////    public LostCard add(@RequestBody LostCard lostCard) {
////        return this.patientDao.addrequest(lostCard);
////    }
//
//}
