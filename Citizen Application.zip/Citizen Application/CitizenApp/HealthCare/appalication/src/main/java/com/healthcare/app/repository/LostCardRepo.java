//package com.ayaagroup.demo.repository;
//
//import model.entity.ContactUs.LostCard;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface LostCardRepo extends JpaRepository<LostCard, Integer> {
//}
