package com.healthcare.app.model.dto;

import lombok.*;
import com.healthcare.app.model.entity.user.patient.DiseaseEntity;
import com.healthcare.app.model.entity.user.patient.PatientDiseaseEntity;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BasicInfoDto {

//    private Integer pdId;
//
//
//    private Patient patientId;

    private DiseaseEntity diseaseEntity;


    private String bloodPressure;


    private String bloodType;


    private String Diabietes;


    private String heartDisease;


    private String Alcohol;

    private String treatment;


    private String tumors;

    public static BasicInfoDto toDto(PatientDiseaseEntity entity){
        return BasicInfoDto.builder()
                .diseaseEntity(entity.getDiseaseEntity())
                .bloodPressure(entity.getBloodPressure())
                .bloodType(entity.getBloodType())
                .Diabietes(entity.getDiabietes())
                .heartDisease(entity.getHeartDisease())
                .Alcohol(entity.getAlcohol())
                .treatment(entity.getTreatment())
                .tumors(entity.getTumors())
                .build();
    }
}
