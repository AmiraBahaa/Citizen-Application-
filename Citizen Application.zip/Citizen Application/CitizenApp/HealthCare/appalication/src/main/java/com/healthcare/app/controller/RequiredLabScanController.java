package com.healthcare.app.controller;

//import com.ayaagroup.demo.dao.PatientDao;
//import model.entity.prescription.LabScans;
//import model.entity.prescription.LabTests;

import com.healthcare.app.Service.BasicInfoService;
import com.healthcare.app.model.dto.scansRequiredDto;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class RequiredLabScanController {

   // @Autowired
  //  private PatientDao patientDao;

    @Autowired
    private BasicInfoService basicInfoService;

    @GetMapping("/scanRequired")
    public scansRequiredDto getScan(@RequestParam Integer id){
        return basicInfoService.getScan(id);
    }

//    @GetMapping("/scanRequired")
//    public List<LabScans> findLabScansByPrescriptionEntity(@RequestParam Integer Id){
//        return this.patientDao.findLabScansByPrescriptionId(Id);
//    }

//    @GetMapping("/testRequired")
//    public List<LabTests> findAllByPreId(Integer Id){
//        return this.patientDao.findAllByPreId(Id);
//    }
//
//    @GetMapping(path = "/prescription/LabSection/RequiresTests")
//    public List<LabTests> findLabTestsByPrescriptionId(@RequestParam Integer id){
//        return this.patientDao.findLabTestByPrescriptionId(id);
//    }
}
